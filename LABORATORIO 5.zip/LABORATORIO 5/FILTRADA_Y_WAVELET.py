import numpy as np
import matplotlib.pyplot as plt
import csv
from scipy.signal import butter, sosfilt, cwt, morlet2, find_peaks

# Parámetros
fs = 250  # Frecuencia de muestreo en Hz
low = 0.05
high = 40 
orden = 1

# Filtro pasa banda
sos = butter(orden, [low, high], btype='bandpass', fs=fs, output='sos')

# Leer archivo CSV
filename = "senal_corazon.csv"
data = []
timestamps = []

with open(filename, mode='r') as file:
    reader = csv.reader(file)
    next(reader)
    for row in reader:
        timestamps.append(float(row[0]))
        data.append(float(row[1]))

data = np.array(data)

# Filtrar señal
filtered_data = sosfilt(sos, data)

# Transformada Wavelet Continua con Morlet
widths = np.arange(1, 50)
cwt_matrix = cwt(filtered_data, morlet2, widths, w=5)

# Escala de mejor contraste
cwt_abs = np.abs(cwt_matrix)
cwt_sum = np.sum(cwt_abs, axis=0)
normalized_cwt = (cwt_sum - np.min(cwt_sum)) / (np.max(cwt_sum) - np.min(cwt_sum))

# Detección de picos R
peaks, _ = find_peaks(normalized_cwt, distance=fs*0.4, height=0.3)

# Calcular intervalos R-R en segundos
rr_intervals = np.diff(np.array(timestamps)[peaks])

# Métricas de HRV
rr_mean = np.mean(rr_intervals)
sdnn = np.std(rr_intervals)
rmssd = np.sqrt(np.mean(np.square(np.diff(rr_intervals))))
nn50 = np.sum(np.abs(np.diff(rr_intervals)) > 0.05)
pnn50 = (nn50 / len(rr_intervals)) * 100 if len(rr_intervals) > 0 else 0

# Imprimir métricas
print("\n--- Métricas de HRV (dominio del tiempo) ---")
print(f"Promedio RR: {rr_mean:.3f} s")
print(f"SDNN: {sdnn:.3f} s")
print(f"RMSSD: {rmssd:.3f} s")
print(f"pNN50: {pnn50:.2f} %")

# --- Graficar resultados ---
plt.figure(figsize=(12, 6))
plt.plot(timestamps, filtered_data, label="Señal Filtrada", color="r", alpha=0.7)
plt.plot(np.array(timestamps)[peaks], filtered_data[peaks], 'ko', label="Picos R")
plt.xlabel("Tiempo (s)")
plt.ylabel("Voltaje (V)")
plt.title(f"Picos R detectados - RR medio: {rr_mean:.3f} s")
plt.legend()
plt.grid(True)
plt.tight_layout()
plt.show()
